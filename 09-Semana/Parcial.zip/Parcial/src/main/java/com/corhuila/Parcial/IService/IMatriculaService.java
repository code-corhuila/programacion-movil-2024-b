package com.corhuila.Parcial.IService;

import com.corhuila.Parcial.Entitity.Matricula;

public interface IMatriculaService extends IBaseService<Matricula>{

}
