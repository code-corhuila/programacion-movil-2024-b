package com.corhuila.Parcial.IRepository;


import com.corhuila.Parcial.Entitity.Estudiante;
import org.springframework.stereotype.Repository;

@Repository
public interface IEstudianteRepository extends IBaseRepository<Estudiante, Long>{

}