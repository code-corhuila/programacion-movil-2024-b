package com.corhuila.Parcial.IRepository;


import com.corhuila.Parcial.Entitity.Matricula;
import org.springframework.stereotype.Repository;

@Repository
public interface IMatriculaRepository extends IBaseRepository<Matricula, Long>{

}