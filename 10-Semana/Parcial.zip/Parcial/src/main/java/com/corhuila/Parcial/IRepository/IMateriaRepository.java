package com.corhuila.Parcial.IRepository;


import com.corhuila.Parcial.Entitity.Materia;
import org.springframework.stereotype.Repository;

@Repository
public interface IMateriaRepository extends IBaseRepository<Materia, Long>{

}