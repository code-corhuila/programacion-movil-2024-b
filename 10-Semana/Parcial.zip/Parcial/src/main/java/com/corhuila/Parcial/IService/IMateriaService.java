package com.corhuila.Parcial.IService;

import com.corhuila.Parcial.Entitity.Materia;

public interface IMateriaService extends IBaseService<Materia>{

}
