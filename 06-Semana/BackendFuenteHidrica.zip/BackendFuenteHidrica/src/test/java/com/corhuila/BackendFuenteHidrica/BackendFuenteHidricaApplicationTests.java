package com.corhuila.BackendFuenteHidrica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendFuenteHidricaApplicationTests {

	@Test
	void contextLoads() {
	}

}
