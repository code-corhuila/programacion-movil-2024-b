package com.corhuila.BackendFuenteHidrica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendFuenteHidricaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendFuenteHidricaApplication.class, args);
	}

}
